Summit question import packages

Extract this bundle, then import one question ZIP at a time.
Each question ZIP contains task.json at its root, including the question, answer key and solution.

These are import drafts, not submission-ready tasks. All 26 source tasks currently lack the required author-written rubric. Complete 3–5 objective criteria totaling 10 points, with exactly one final-answer criterion.
Review the task's review.json in the repository for remaining author actions. Confirm text-only eligibility, authorship, references, and formatting before submitting. No images are included because none exist in the source data.
