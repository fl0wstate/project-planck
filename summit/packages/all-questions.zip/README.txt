Summit question import packages

Extract this bundle, then import one question ZIP at a time.
Each question ZIP contains task.json at its root, including the question, answer key and solution.

All packages include a 10-point rubric with one final-answer criterion.
Rubrics are AI-assisted, based on the existing solutions. Use these packages only in a workflow that permits AI-assisted content. They do not satisfy the archived Summit human-authorship restriction.
After import, inspect the form and submit each question individually. Confirm assigned domain and text-only eligibility. Local package validation does not certify scientific correctness or platform acceptance.
